"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([["test___fixtures_config_int_scatterplot-palmer-penguins_json"],{

/***/ "./test/__fixtures/config/int/scatterplot-palmer-penguins.json":
/*!*********************************************************************!*\
  !*** ./test/__fixtures/config/int/scatterplot-palmer-penguins.json ***!
  \*********************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = JSON.parse('{"key":"cfNkIaMvN_xL","data":{"state":"DESCRIBING_CHART","dataSet":"https://environment.ld.admin.ch/foen/palmer-penguins/18","dataSource":{"type":"sparql","url":"https://int.lindas.admin.ch/query"},"meta":{"title":{"de":"","fr":"","it":"","en":"Mean bill depth vs mean bill depth for Adelie Penguins"},"description":{"de":"","fr":"","it":"","en":""}},"chartConfig":{"version":"1.2.1","chartType":"scatterplot","filters":{"https://environment.ld.admin.ch/foen/palmer-penguins/species":{"type":"single","value":"https://environment.ld.admin.ch/foen/palmer-penguins/species/Adelie"},"https://environment.ld.admin.ch/foen/palmer-penguins/sex":{"type":"single","value":"female"},"https://environment.ld.admin.ch/foen/palmer-penguins/year":{"type":"single","value":"2007"}},"cubes":[],"interactiveFiltersConfig":{"legend":{"active":false,"componentIri":""},"timeRange":{"active":false,"componentIri":"","presets":{"type":"range","from":"","to":""}},"dataFilters":{"active":false,"componentIris":[]}},"fields":{"x":{"componentIri":"https://environment.ld.admin.ch/foen/palmer-penguins/billlengthmm"},"y":{"componentIri":"https://environment.ld.admin.ch/foen/palmer-penguins/billdepthmm"},"segment":{"componentIri":"https://environment.ld.admin.ch/foen/palmer-penguins/islands","palette":"category10","colorMapping":{"https://environment.ld.admin.ch/foen/palmer-penguins/islands/Biscoe":"#1f77b4","https://environment.ld.admin.ch/foen/palmer-penguins/islands/Dream":"#ff7f0e","https://environment.ld.admin.ch/foen/palmer-penguins/islands/Torgersen":"#2ca02c"}}}},"activeField":"title"}}');

/***/ })

}]);