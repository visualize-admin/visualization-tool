"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([["test___fixtures_config_int_pie-red-list_json"],{

/***/ "./test/__fixtures/config/int/pie-red-list.json":
/*!******************************************************!*\
  !*** ./test/__fixtures/config/int/pie-red-list.json ***!
  \******************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = JSON.parse('{"key":"Z6Re21LHbOoP","data":{"dataSet":"https://environment.ld.admin.ch/foen/UBD003002/5","dataSource":{"type":"sparql","url":"https://int.lindas.admin.ch/query"},"meta":{"title":{"de":"","fr":"","it":"","en":"Amphibians red list status"},"description":{"de":"","fr":"","it":"","en":""}},"chartConfig":{"version":"1.2.1","chartType":"pie","filters":{"https://environment.ld.admin.ch/foen/UBD003002/artengruppe":{"type":"single","value":"https://environment.ld.admin.ch/foen/UBD003002/ArtenGruppe/AMPH"}},"interactiveFiltersConfig":{"legend":{"active":false,"componentIri":""},"timeRange":{"active":false,"componentIri":"","presets":{"type":"range","from":"","to":""}},"dataFilters":{"active":false,"componentIris":[]}},"fields":{"y":{"componentIri":"https://environment.ld.admin.ch/foen/UBD003002/value"},"segment":{"componentIri":"https://environment.ld.admin.ch/foen/UBD003002/status","palette":"category10","sorting":{"sortingType":"byMeasure","sortingOrder":"asc"},"colorMapping":{"https://environment.ld.admin.ch/foen/UBD003002/Status/DD":"#1f77b4","https://environment.ld.admin.ch/foen/UBD003002/Status/LC":"#ff7f0e","https://environment.ld.admin.ch/foen/UBD003002/Status/NT":"#2ca02c","https://environment.ld.admin.ch/foen/UBD003002/Status/VU":"#d62728","https://environment.ld.admin.ch/foen/UBD003002/Status/EN":"#9467bd","https://environment.ld.admin.ch/foen/UBD003002/Status/CR":"#8c564b","https://environment.ld.admin.ch/foen/UBD003002/Status/RE":"#e377c2","https://environment.ld.admin.ch/foen/UBD003002/Status/EX":"#7f7f7f"}}}},"activeField":"title"}}');

/***/ })

}]);