"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([["test___fixtures_config_int_bathing-water-quality-hierarchie_json"],{

/***/ "./test/__fixtures/config/int/bathing-water-quality-hierarchie.json":
/*!**************************************************************************!*\
  !*** ./test/__fixtures/config/int/bathing-water-quality-hierarchie.json ***!
  \**************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = JSON.parse('{"key":"nI6X4V_EcK2c","data":{"meta":{"title":{"de":"","en":"","fr":"","it":""},"description":{"de":"","en":"","fr":"","it":""}},"dataSet":"https://environment.ld.admin.ch/foen/ubd0104/11","dataSource":{"url":"https://int.lindas.admin.ch/query","type":"sparql"},"chartConfig":{"fields":{"x":{"sorting":{"sortingType":"byAuto","sortingOrder":"asc"},"componentIri":"https://environment.ld.admin.ch/foen/ubd0104/dateofprobing"},"y":{"componentIri":"https://environment.ld.admin.ch/foen/ubd0104/value"}},"filters":{"https://environment.ld.admin.ch/foen/ubd0104/location":{"type":"single","value":"https://ld.admin.ch/dimension/bgdi/inlandwaters/bathingwater/CH19007"},"https://environment.ld.admin.ch/foen/ubd0104/parametertype":{"type":"single","value":"E.coli"}},"version":"1.4.2","chartType":"column","interactiveFiltersConfig":{"legend":{"active":false,"componentIri":""},"timeRange":{"active":false,"presets":{"to":"","from":"","type":"range"},"componentIri":""},"dataFilters":{"active":true,"componentIris":["https://environment.ld.admin.ch/foen/ubd0104/location"]},"calculation":{"active":false,"type":"identity"}}}}}');

/***/ })

}]);