"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_N_E"] = self["webpackChunk_N_E"] || []).push([["test___fixtures_config_int_column-heavy-metals_json"],{

/***/ "./test/__fixtures/config/int/column-heavy-metals.json":
/*!*************************************************************!*\
  !*** ./test/__fixtures/config/int/column-heavy-metals.json ***!
  \*************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

module.exports = JSON.parse('{"key":"rOAYJqoZQKlU","data":{"meta":{"title":{"de":"","en":"Heavy Metal Concentration in St Martin","fr":"Concentration en métaux lourds à St Martin","it":""},"description":{"de":"","en":"","fr":"","it":""}},"dataSet":"https://environment.ld.admin.ch/foen/ubd0066/15","dataSource":{"type":"sparql","url":"https://int.lindas.admin.ch/query"},"chartConfig":{"version":"1.2.1","fields":{"x":{"sorting":{"sortingType":"byDimensionLabel","sortingOrder":"asc"},"componentIri":"https://environment.ld.admin.ch/foen/ubd0066/messparameter"},"y":{"componentIri":"https://environment.ld.admin.ch/foen/ubd0066/wert"}},"filters":{"https://environment.ld.admin.ch/foen/ubd0066/station":{"type":"single","value":"https://environment.ld.admin.ch/foen/ubd0066/Station/100_1"},"https://environment.ld.admin.ch/foen/ubd0066/samplingperiod":{"type":"single","value":"https://environment.ld.admin.ch/foen/ubd0066/samplingperiod/1"}},"chartType":"column","interactiveFiltersConfig":{"timeRange":{"active":false,"presets":{"to":"","from":"","type":"range"},"componentIri":""},"legend":{"active":false,"componentIri":""},"dataFilters":{"active":false,"componentIris":[]}}}}}');

/***/ })

}]);